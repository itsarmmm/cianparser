import requests
from bs4 import BeautifulSoup as bs
import time
import openpyxl

#to install dryscrape follow this tutorial - https://stackoverflow.com/questions/38788816/pip-install-dryscrape-fails-with-error-errno-2-no-such-file-or-directory-s
import dryscrape


def collect_listing_urls():
    INPUT_DATE = input("How many days before? (Leave blank if you want data of last 7 days) -> ")
    if INPUT_DATE == "":
        INPUT_DATE = 7

    DATE_IN_SECONDS = 100
    PAGE = 1
    LISTING_URLS = []

    while True:
        URL = f"https://www.cian.ru/cat.php?deal_type=sale&engine_version=2&offer_type=flat&p={PAGE}&region=1&totime={DATE_IN_SECONDS}"
        r = requests.get(URL, allow_redirects=False) # setting allow_redirects=False, because site redirects to page 1 if listings not exists
        soup = bs(r.content, "html.parser")

        listings = soup.find_all("div", {"class": "_93444fe79c--general--2SDGY"})

        if len(listings):
            for item in listings:
                link = item.find('a')['href']
                LISTING_URLS.append(link)
            PAGE += 1
        else:
            print("success")
            break
    return LISTING_URLS



def collect_information():
    count = 1
    data = []
    for link in LISTING_URLS:

        # this url checks my browser for javascript, so i had to use dryscrape technology in this case
        session = dryscrape.Session()
        session.visit(link)
        response = session.body()
        soup = bs(response, 'html.parser')

        name = soup.find_all("h1", class_="a10a3f92e9--title--2Widg")[0].text # Название

        description = soup.find_all("p", class_="a10a3f92e9--description-text--3Sal4")[0].text # Описание

        address = soup.find_all("address", class_="a10a3f92e9--address--140Ec")[0].text # Адрес

        price = soup.find_all("span", class_="a10a3f92e9--price_value--1iPpd")[0].text # Цена

        specification_bar = soup.find_all("div", class_="a10a3f92e9--info-value--18c8R")


        try:
            general = specification_bar[0].text #Общая
        except:
            general = ""
            pass

        try:
            residential = specification_bar[1].text #Жилая
        except:
            residential = ""
            pass

        try:
            kitchen = specification_bar[2].text #Кухня
        except:
            kitchen = ""
            pass

        try:
            stage = specification_bar[3].text #Этаж
        except:
            stage = ""
            pass

        try:
            built = specification_bar[4].text #Построен
        except:
            built = ""
            pass


        technical_info_bar = soup.find_all("span", class_="a10a3f92e9--value--3Ftu5")

        try:
            type = technical_info_bar[0].text #Тип жилья
        except:
            type = ""
            pass

        try:
            layout = technical_info_bar[1].text #Планировка
        except:
            layout = ""
            pass

        try:
            room_area = technical_info_bar[2].text #Площадь комнат
        except:
            room_area = ""
            pass

        try:
            bathroom = technical_info_bar[3].text #Санузел
        except:
            bathroom = ""
            pass

        try:
            balcony = technical_info_bar[4].text #Балкон
        except:
            balcony = ""
            pass

        try:
            repair = technical_info_bar[5].text #Ремонт
        except:
            repair = ""
            pass

        data.append([link, name, description, address, price, general, residential, kitchen, stage, built, type, layout, room_area, bathroom, balcony, repair])

    print("finished")
    return data


def save_to_excel(data):
    xlsx = openpyxl.Workbook()

    sheet = xlsx.active

    # entering data into the cells
    sheet.cell(row = 1, column = 1).value = "Ссылка"
    sheet.cell(row = 1, column = 2).value = "Название"
    sheet.cell(row = 1, column = 3).value = "Описание"
    sheet.cell(row = 1, column = 4).value = "Адрес"
    sheet.cell(row = 1, column = 5).value = "Цена"
    sheet.cell(row = 1, column = 6).value = "Общая Площадь"
    sheet.cell(row = 1, column = 7).value = "Жилая Площадь"
    sheet.cell(row = 1, column = 8).value = "Кухня"
    sheet.cell(row = 1, column = 9).value = "Этаж"
    sheet.cell(row = 1, column = 10).value = "Построен"
    sheet.cell(row = 1, column = 11).value = "Тип жилья"
    sheet.cell(row = 1, column = 12).value = "Планировка"
    sheet.cell(row = 1, column = 13).value = "Площадь комнат"
    sheet.cell(row = 1, column = 14).value = "Санузел"
    sheet.cell(row = 1, column = 15).value = "Балкон"
    sheet.cell(row = 1, column = 16).value = "Ремонт"

    for row in data:
        sheet.append(row)


    xlsx.save('write_to_cell.xlsx')


if __name__ == "__main__":
    LISTING_URLS = collect_listing_urls()

    DATA = collect_information()

    save_to_excel(DATA)
